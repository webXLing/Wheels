import model from './model'
import show from './show'

export default {
  model,
  show
}
